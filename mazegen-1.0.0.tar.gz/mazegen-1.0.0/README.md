*This project has been created as part of the 42 curriculum by sasheri, vebastos.*

# A-Maze-ing

## Description

A-Maze-ing is a Python project that reads a configuration file, generates a random maze,
displays it visually with user interactions, and writes the first generated maze to an
output file using the hexadecimal wall format required by the subject.

The project is split into two parts:

- a reusable maze generation package named `mazegen`,
- a graphical application launched by `a_maze_ing.py`.

The reusable class is `MazeGenerator`. It handles validation, maze generation,
"42" blocked-mask placement, optional imperfect-maze loop creation, shortest-path
computation, and output formatting.

## Instructions

### Requirements

- Python 3.10 or newer
- a virtual environment is recommended
- one MLX Python wheel available locally for the graphical display

Accepted MLX wheel names in this repository:

- `mlx-2.2-py3-ubuntu-any.whl`
- `mlx-2.2-py3-fedora-any.whl`
- `mlx-2.2-py3-none-any.whl`

### Run the project

The program must be launched with exactly one argument:

```bash
python3 a_maze_ing.py config.txt
```

### Makefile targets

```bash
make install
make run
make debug
make lint
make clean
```

Optional helpers:

```bash
make lint-strict
make package
```

### Interactive controls

The graphical application provides the mandatory interactions required by the subject:

- `1` regenerates a new maze,
- `2` shows or hides the shortest path,
- `3` changes the wall colour palette,
- `4`, `q`, or `Esc` quits the program.

## Configuration File

The configuration file is a plain text file made of one `KEY=VALUE` pair per line.
Comment lines begin with `#` and are ignored. Keys are case-insensitive in the parser.

### Mandatory keys

| Key | Type | Description | Example |
|---|---|---|---|
| `WIDTH` | integer | maze width in cells | `WIDTH=20` |
| `HEIGHT` | integer | maze height in cells | `HEIGHT=15` |
| `ENTRY` | `x,y` integers | entry coordinates | `ENTRY=0,0` |
| `EXIT` | `x,y` integers | exit coordinates | `EXIT=19,14` |
| `OUTPUT_FILE` | string | output filename | `OUTPUT_FILE=maze.txt` |
| `PERFECT` | boolean | `True` for a perfect maze, `False` for an imperfect maze | `PERFECT=True` |

### Optional key

| Key | Type | Description | Example |
|---|---|---|---|
| `SEED` | integer | fixed random seed for reproducible generation | `SEED=42` |

### Example default configuration

```text
WIDTH=10
HEIGHT=10
ENTRY=0,0
EXIT=9,9
OUTPUT_FILE=maze_output.txt
PERFECT=False
SEED=42
```

### Error handling checked by the parser

The program rejects:

- missing mandatory keys,
- duplicated keys,
- unknown keys,
- lines without `=`,
- invalid integers,
- invalid `ENTRY` or `EXIT` tuple format,
- invalid boolean values for `PERFECT`.

## Chosen Maze Generation Algorithm

The maze is generated with iterative Depth-First Search (DFS) backtracking.

### Why this algorithm was chosen

DFS is a good fit for this project because it is simple to explain, easy to implement,
fast enough for the required maze sizes, and naturally produces a perfect maze structure
before optional post-processing.

For imperfect mazes, the project opens extra walls afterward to create loops while still
trying to avoid invalid large fully open zones.

## Solving Algorithm

The shortest path is computed with Breadth-First Search (BFS).
Because the maze graph is unweighted, BFS guarantees one valid shortest path from the
entry to the exit.

## The "42" Pattern

The project preserves a visible `42` pattern by marking specific cells as fully blocked.
These blocked cells are never carved by the generator and are ignored by the solver.
If the maze is too small to place the pattern safely, the program prints a warning and
continues without the pattern.

## Reusable Module

The reusable part of the project is the `MazeGen/` package distributed as a standard
Python package named `mazegen-*`.

### Import and basic use

```python
from MazeGen import MazeGenerator

maze = MazeGenerator(
    width=20,
    height=15,
    entry=(0, 0),
    exit_=(19, 14),
    output_file="maze.txt",
    perfect=True,
    seed=42,
)
maze.generate()
print(maze.to_hex_string())
print(maze.get_solution())
```

### Custom parameters

You can change:

- width and height,
- entry and exit coordinates,
- output filename,
- perfect or imperfect generation,
- seed for reproducible output.

### Accessible reusable data

The module exposes at least:

- `generate()` to create the maze,
- `get_grid()` to access the internal wall grid,
- `get_blocked_mask()` to access the blocked `42` mask,
- `get_solution()` to access one shortest valid solution,
- `build_output_text()` to obtain the text expected by the subject output file.

### Build the package

```bash
python3 -m pip install --upgrade build
python3 -m build
```

This creates the standard artifacts in `dist/`. For the evaluation repository, the final
package file must also be copied to the project root.

## Team and Project Management

### Roles

- `sasheri`: reusable maze package, generation logic, solver, blocked-mask logic,
  validation inside the maze module.
- `vebastos`: application integration, graphical display, project wiring, and repository
  organization.

### Initial planning and how it evolved

The first plan was to split the work into two layers: a reusable backend package and a
small front-end application. During development, more time than expected was spent on
integrating the display with the reusable package and on matching the exact output format
required by the subject.

### What worked well

- clear split between reusable logic and application code,
- deterministic generation with a seed,
- shortest-path extraction separated from display logic.

### What could be improved

- add more automatic tests before the defence,
- document packaging and submission steps earlier,
- run the full flake8 and mypy checks more often during development.

### Tools used

- Python 3.10+
- MLX Python bindings for the display
- flake8
- mypy
- virtual environments
- Git and GitHub/Git repository workflow

## Resources and AI Usage

### References

- Python documentation: packaging, typing, `random`, and file handling
- setuptools documentation
- Breadth-First Search and Depth-First Search algorithm references
- 42 project subject and peer-evaluation scale
- MiniLibX / MLX Python bindings documentation when available

### AI usage

AI tools were used as assistants for:

- reviewing documentation wording,
- checking README completeness,
- identifying packaging and evaluation risks,
- improving code clarity and small refactors.

AI was not used as a substitute for understanding the project. The final code, explanations,
and defence preparation must still be understood and justified by the team.
